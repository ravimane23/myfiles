jQuery(function($){
	$(document).ready(function(){
		//dropdowns
		$("#main-menu ul.menu").superfish({ 
			autoArrows: true,
			animation:  {opacity:'show',height:'show'}
		});
	}); // END doc ready
}); // END function