// $Id$

/**
 * @file
 * OM Scripts
 *
 * @author: Daniel Honrade http://drupal.org/user/351112
 *
 */
 
jQuery(document).ready(function($){
	
/**
 * Disabled this functionality due to colorbox compatibility problem
 * for external links, open in new window
  $('a[href^=http]').click( function() {
    window.open(this.href);
    return false;	    
  });
 *
 */
}); 
