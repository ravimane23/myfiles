jQuery(document).ready(function() {

	jQuery('#slider').nivoSlider({
		effect:'random',
		slices:10,
		animSpeed: 500
	});
  
});