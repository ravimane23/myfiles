(function ($) {	
    jQuery(document).ready(function($) {
	    $('#organization-node-form fieldset').hide();
      $( '#edit-field-bpso-type-und').change( function() {
	      if ( $(this).val() == 'Academic School of Nursing' ) { 
		  $('#organization-node-form fieldset').hide(); 
		  resetForm($('#organization-node-form fieldset'));
		  $('.group-academic-school-of-nursing').show();
	      } else if ( $(this).val() == 'Community Care' ) {
		  $('#organization-node-form fieldset').hide();
		  resetForm($('#organization-node-form fieldset'));
		  $('.group-community-care').show();
	      } else if ( $(this).val() == 'Home Health Care' ) {
		  $('#organization-node-form fieldset').hide();
		  resetForm($('#organization-node-form fieldset'));
		  $('.group-home-health-care').show();
	      } else if ( $(this).val() == 'Hospital' ) {
		  $('#organization-node-form fieldset').hide();
		  resetForm($('#organization-node-form fieldset'));
		  $('.group-hospital').show();
	      } else if ( $(this).val() == 'Integrated Provider Organization' ) {
		  $('#organization-node-form fieldset').hide();
		  resetForm($('#organization-node-form fieldset'));
		  $('.group-ipo').show();
	      } else if ( $(this).val() == 'Public Health' ) {
		  $('#organization-node-form fieldset').hide();
		  resetForm($('#organization-node-form fieldset'));
		  $('.group-public-health').show();
	      } else {
		  $('#organization-node-form fieldset').hide();
		  resetForm($('#organization-node-form fieldset'));
	      }
});


function resetForm( form ) {
    form.find('input:text, select').val('');
}
});


})(jQuery);

