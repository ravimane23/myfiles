(function ($) {
    $(document).ready(function(){


	    $("table tr td div select").change(function() {
		    var id = this.id;
		    var idValue = this.value;
		    var rowValues = $("#"+id).attr('name');
		    if( idValue == 0 ){
			if( confirm ( "This will create smoking cessation quarter reports for you to complete and prompt you to do so every quarter. Click OK to proceed or Cancel to go back.") ) {
			    createContentType(rowValues+"_create");
			}else{
			    return false;
			}
		    }else{
			if( confirm ( "This will delete the information about what smoking cessation information you have submitted and any in progress data, and will make it so the system no longer prompts you to enter smoking cessation information every quarter. Data previously submitted to NQuIRE will not be removed from the central NQuIRE system. Click OK to proceed or Cancel to go back.") ) {
			    createContentType(rowValues+"_delete");
			}else{
			    return false;
			}
		    }
		});
	    function createContentType(rowValues){
		jQuery.ajax({
			url: 'bpgunit/action?id='+rowValues,
			    success: function(data) {
			    jQuery('#event').html(data);   
			}
		    });
	    }
	});
})(jQuery);